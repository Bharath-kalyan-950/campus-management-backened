import React from 'react';
import { Landing } from './pages/Landing';
export function App() {
  return <Landing />;
}